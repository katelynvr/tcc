package estudoCaso;

import javax.swing.JOptionPane;

public class Compra
{
	public static void main(String[] args)
	{
		String resposta = JOptionPane.showInputDialog("PF ou PJ?");
				
		if(resposta.equalsIgnoreCase("PF"))
		{	PessoaFisica objPF = new PessoaFisica();	}
		else
		{	PessoaJuridica objPJ = new PessoaJuridica();	}
	}
}