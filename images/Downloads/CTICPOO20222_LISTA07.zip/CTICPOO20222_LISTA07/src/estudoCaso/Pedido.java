package estudoCaso;

import javax.swing.JOptionPane;

public class Pedido
{
	//atributos comuns
	private String numeroPedido;
	private float quantidade;
	private String data;
	
	//atributo de refer�ncia
	private Fatura atRefFatura;
	private Produto atRefProduto;
	private Cliente atRefCliente;
	
	//m�todos de acesso para atributos comuns
	public String getNumeroPedido()
	{	return numeroPedido;	}
	
	public void setNumeroPedido(String numeroPedido)
	{	this.numeroPedido = numeroPedido;	}
	
	public float getQuantidade()
	{	return quantidade;	}
	
	public void setQuantidade(float quantidade)
	{	this.quantidade = quantidade;	}
	
	public String getData()
	{	return data;	}
	
	public void setData(String data)
	{	this.data = data;	}
	
	//m�todos de acesso para atributo de refer�ncia	
	public Fatura getAtRefFatura()
	{	return atRefFatura;	}

	public void setAtRefFatura(Fatura atRefFatura)
	{	this.atRefFatura = atRefFatura;	}
	
	public Produto getAtRefProduto()
	{	return atRefProduto;	}

	public void setAtRefProduto(Produto atRefProduto)
	{	this.atRefProduto = atRefProduto;	}
	
	public Cliente getAtRefCliente()
	{	return atRefCliente;	}

	public void setAtRefCliente(Cliente atRefCliente)
	{	this.atRefCliente = atRefCliente;	}

	//m�todo construtor
	public Pedido()
	{	numeroPedido = JOptionPane.showInputDialog("Informe o n�mero do pedido:");
		quantidade = Float.parseFloat(JOptionPane.showInputDialog("Informe a quantidade do pedido:"));
		data = JOptionPane.showInputDialog("Informe a data do pedido:");
	}
	
	//opera��o
	public void gerarFatura()
	{	Fatura objF = new Fatura();
		atRefFatura = objF;
		atRefFatura.setValorTotal(quantidade*atRefProduto.getPrecoUnitario());
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}