package estudoCaso;

import javax.swing.JOptionPane;

public class PessoaJuridica extends Cliente
{
	//atributo comum
	private String cnpj;
	
	//m�todos de acesso para atributo comum
	public String getCnpj()
	{	return cnpj;	}

	public void setCnpj(String cnpj)
	{	this.cnpj = cnpj;	}
			
	//m�todo construtor
	public PessoaJuridica()
	{	super();
		cnpj = JOptionPane.showInputDialog("Informe o cnpj da Pessoa Jur�dica:");
		fazerPedido();
		imprimirFatura();
	}
}