package estudoCaso;

import javax.swing.JOptionPane;

public class PessoaFisica extends Cliente
{
	//atributos comuns
	private String cpf;
	private String dtNascimento;
		
	//m�todos de acesso para atributos comuns
	public String getCpf()
	{	return cpf;	}
		
	public void setCpf(String cpf) 
	{	this.cpf = cpf;	}
		
	public String getDtNascimento()
	{	return dtNascimento;	}
		
	public void setDtNascimento(String dtNascimento)
	{	this.dtNascimento = dtNascimento;	}
		
	//m�todo construtor
	public PessoaFisica()
	{	super();
		cpf = JOptionPane.showInputDialog("Informe o CPF da Pessoa F�sica:");
		dtNascimento = JOptionPane.showInputDialog("Informe a data de nascimento da Pessoa F�sica:");
		fazerPedido();
		imprimirFatura();
	}	
}