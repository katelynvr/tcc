package estudoCaso;

import javax.swing.JOptionPane;

public abstract class Cliente
{
	//atributo comum
	protected String nome;
	
	//atributos de refer�ncia
	protected Telefone atRefTelefone;
	protected Endereco atRefEndereco;
	protected Produto atRefProduto;
	protected Pedido atRefPedido;
	
	//m�todos de acesso para atributo comum
	public String getNome()
	{	return nome;	}

	public void setNome(String nome)
	{	this.nome = nome;	}
	
	//m�todos de acesso para atributos de refer�ncia
	public Telefone getAtReftelefone()
	{	return atRefTelefone;	}

	public void setAtReftelefone(Telefone atReftelefone)
	{	this.atRefTelefone = atReftelefone;	}

	public Endereco getAtRefEndereco()
	{	return atRefEndereco;	}

	public void setAtRefEndereco(Endereco atRefEndereco)
	{	this.atRefEndereco = atRefEndereco;	}

	public Produto getAtRefProduto()
	{	return atRefProduto;	}

	public void setAtRefProduto(Produto atRefProduto)
	{	this.atRefProduto = atRefProduto;	}

	public Pedido getAtRefPedido()
	{	return atRefPedido;	}

	public void setAtRefPedido(Pedido atRefPedido)
	{	this.atRefPedido = atRefPedido;	}

	//m�todo construtor
	public Cliente()
	{	nome = JOptionPane.showInputDialog("Informe o nome do cliente:");
		Endereco objE = new Endereco();
		Telefone objT = new Telefone();
		atRefEndereco = objE;
		atRefTelefone = objT;
	}

	//opera��es
	public void fazerPedido()
	{	Produto objPr = new Produto();
		Pedido objPe = new Pedido();
		atRefProduto = objPr;
		atRefPedido = objPe;
		atRefPedido.setAtRefProduto(atRefProduto);
		atRefPedido.gerarFatura();		
	}
	
	public void imprimirFatura()
	{	JOptionPane.showMessageDialog(null,"DADOS COMPLETOS DA COMPRA:"
			+ "\n\nDADOS DO CLIENTE:"
			+ "\nNOME: "+nome
			+"\nENDERE�O COMPLETO DO CLIENTE: "+atRefEndereco.getRua()
			+", "+atRefEndereco.getNumero()
			+" "+atRefEndereco.getComplemento()
			+" - "+atRefEndereco.getBairro()
			+" - "+atRefEndereco.getCidade()
			+"/"+atRefEndereco.getEstado()
			+" - CEP: "+atRefEndereco.getCep()
			+"\nTELEFONE DE CONTATO DO CLIENTE: "+atRefTelefone.getDdi()
			+" ("+atRefTelefone.getDdd()
			+") "+atRefTelefone.getNumero()
			+" - "+atRefTelefone.getTipo()
			+" - "+atRefTelefone.getOperadora()
			+"\n\nDADOS DO PRODUTO:"
			+ "\nC�DIGO DO PRODUTO: "+atRefProduto.getCodigo()
			+ "\nNOME DO PRODUTO: "+atRefProduto.getNome()
			+ "\nQUANTIDADE DO PRODUTO: "+atRefProduto.getQuantidade()
			+ "\nPRE�O UNIT�RIO DO PRODUTO: R$ "+atRefProduto.getPrecoUnitario()
			+"\n\nDADOS DO PEDIDO: "
			+ "\nN�MERO DO PEDIDO: "+atRefPedido.getNumeroPedido()
			+ "\nQUANTIDADE DO PEDIDO: "+atRefPedido.getQuantidade()
			+ "\nDATA DO PEDIDO: "+atRefPedido.getData()
			+"\n\nDADOS DA FATURA: "
			+ "\nN�MERO DA FATURA: "+atRefPedido.getAtRefFatura().getNumeroFatura()
			+ "\nDATA DE VENCIMENTO DA FATURA: "+atRefPedido.getAtRefFatura().getDataVencimento()
			+ "\nVALOR TOTAL DA FATURA: R$ "+atRefPedido.getAtRefFatura().getValorTotal());	
	}
}