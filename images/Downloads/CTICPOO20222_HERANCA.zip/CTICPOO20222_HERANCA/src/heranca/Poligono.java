package heranca;

import javax.swing.JOptionPane;

public abstract class Poligono
{
	//atributos comuns
	protected float base;
	protected float altura;
	
	//m�todos de acesso de atributos comuns
	public void setBase(float b)
	{	base=b;	}
	
	public float getBase()
	{	return base;	}
	
	public void setAltura(float a)
	{	altura=a;	}
	
	public float getAltura()
	{	return altura;	}

	//m�todo construtor
	public Poligono()
	{	base = Float.parseFloat(JOptionPane.showInputDialog("Informe a base:"));
		altura = Float.parseFloat(JOptionPane.showInputDialog("Informe a altura:"));
	}
	
	//opera��es abstratas
	public abstract float calcularArea();
	public abstract double calcularPerimetro();
}