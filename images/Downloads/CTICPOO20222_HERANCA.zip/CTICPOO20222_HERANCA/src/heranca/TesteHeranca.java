package heranca;

import javax.swing.JOptionPane;

public class TesteHeranca 
{
	public static void main(String[] args)
	{
		String resposta = JOptionPane.showInputDialog("Ret�ngulo ou Tri�ngulo?");
		
		if (resposta.equalsIgnoreCase("Ret�ngulo"))
		{	Retangulo objR = new Retangulo();
			JOptionPane.showMessageDialog(null,"�rea do ret�ngulo = "+objR.calcularArea());
			JOptionPane.showMessageDialog(null,"Per�metro do ret�ngulo = "+objR.calcularPerimetro());
			JOptionPane.showMessageDialog(null,"Diagonal do ret�ngulo = "+objR.calcularDiagonal());
		}
		else
		{	Triangulo objT = new Triangulo();
			JOptionPane.showMessageDialog(null,"�rea do tri�ngulo = "+objT.calcularArea());
			JOptionPane.showMessageDialog(null,"Per�metro do tri�ngulo = "+objT.calcularPerimetro());
		}
	}
}