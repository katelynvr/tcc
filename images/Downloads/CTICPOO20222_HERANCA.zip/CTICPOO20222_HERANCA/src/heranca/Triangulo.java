package heranca;

import javax.swing.JOptionPane;

public class Triangulo extends Poligono
{
	//atributo comum
	private String tipo;
	
	//atributo de classe
	private static int numeroLados = 3;
	
	//m�todos de acesso comuns
	public void setTipo(String t)
	{	tipo = t;	}

	public String getTipo()
	{	return tipo;	}
	
	//m�todos de acesso de classe
	public static void setNumeroLados(int nl)
	{	numeroLados = nl;	}
	
	public static int getNumeroLados()
	{	return numeroLados;	}
	
	//m�todo construtor
	public Triangulo()
	{	super();
		tipo = JOptionPane.showInputDialog("Informe o tipo do tri�ngulo:");
	}
	
	//opera��es
	public float calcularArea()
	{	return (base*altura)/2;	}
	
	public double calcularPerimetro()
	{
		if(tipo.equalsIgnoreCase("equil�tero"))
		{	return 3*base;	}
		else if (tipo.equalsIgnoreCase("is�sceles"))
		{	double lado = Math.sqrt(Math.pow((base/2),2)+Math.pow(altura,2));
			return (2*lado)+base;	
		}
		else
		{	float lado1 = Float.parseFloat(JOptionPane.showInputDialog("Informe um lado do tri�ngulo:"));
			float lado2 = Float.parseFloat(JOptionPane.showInputDialog("Informe outro lado do tri�ngulo:"));;
			return base+lado1+lado2;
		}
	}
}