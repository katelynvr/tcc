package heranca;

public class Retangulo extends Poligono 
{
	//atributo de classe
	private static int numeroLados = 4;
	
	//m�todos de acesso dos atributos de classe
	public static int getNumeroLados()
	{	return numeroLados;	}

	public static void setNumeroLados(int numeroLados)
	{	Retangulo.numeroLados = numeroLados;	}

	//m�todo construtor
	public Retangulo()
	{	super();	}
	
	//opera��es
	public float calcularArea()
	{	return base*altura;		}

	public double calcularPerimetro()
	{	return 2*(base+altura);		}

	public double calcularDiagonal()
	{	return Math.sqrt(Math.pow(base,2)+Math.pow(altura,2));		}	
}