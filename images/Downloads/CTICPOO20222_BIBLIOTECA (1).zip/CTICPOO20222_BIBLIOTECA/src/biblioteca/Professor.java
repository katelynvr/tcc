package biblioteca;

import javax.swing.JOptionPane;

public class Professor extends Usuario
{
	//atributos comuns
	private String titulacao;
	private String dataAdmissao;
	
	//m�todos de acesso
	public String getTitulacao()
	{	return titulacao;	}
	
	public void setTitulacao(String titulacao)
	{	this.titulacao = titulacao;	}
	
	public String getDataAdmissao()
	{	return dataAdmissao;	}
	
	public void setDataAdmissao(String dataAdmissao)
	{	this.dataAdmissao = dataAdmissao;	}
	
	//m�todo construtor
	public Professor()
	{	super();
		titulacao = JOptionPane.showInputDialog("Informe a titula��o do professor: ");
		dataAdmissao = JOptionPane.showInputDialog("Informe a data de admiss�o do professor: ");		
	}
	
	//opera��o
	public void imprimirComprovante()
	{	super.imprimirComprovante();
		JOptionPane.showMessageDialog(null,"DADOS ESPEC�FICOS DO USU�RIO PROFESSOR: "
				+"\nTITULA��O........: "+titulacao
				+"\nDATA DE ADMISS�O.: "+dataAdmissao);
	}

}