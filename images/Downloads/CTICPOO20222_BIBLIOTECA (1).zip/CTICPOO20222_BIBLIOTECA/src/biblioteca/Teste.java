package biblioteca;

import javax.swing.JOptionPane;

public class Teste
{
	public static void main(String[] args)
	{
		String resposta = JOptionPane.showInputDialog("Professor ou Aluno?");
		
		if(resposta.equalsIgnoreCase("Professor"))
		{	Professor objP = new Professor();
			objP.fazerEmprestimo();
			objP.imprimirComprovante();
		}
		else
		{	Aluno objA = new Aluno();
			objA.fazerEmprestimo();
			objA.imprimirComprovante();
		}
	}
}