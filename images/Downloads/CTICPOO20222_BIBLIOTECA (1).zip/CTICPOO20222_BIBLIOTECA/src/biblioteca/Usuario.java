package biblioteca;

import javax.swing.JOptionPane;

public abstract class Usuario
{
	//atributos comuns
	protected String nome;
	protected String matricula;
	
	//atributo de refer�ncia para tratar o relacionamento
	//simples entre as classes Usuario e Emprestimo
	protected Emprestimo atRefEmprestimo;
	
	//m�todos de acesso dos atributos comuns
	public String getNome()
	{	return nome;	}
	
	public void setNome(String nome)
	{	this.nome = nome;	}
	
	public String getMatricula()
	{	return matricula;	}
	
	public void setMatricula(String matricula)
	{	this.matricula = matricula;	}
	
	//m�todos de acesso do atributo de refer�ncia
	public Emprestimo getAtRefEmprestimo()
	{	return atRefEmprestimo;	}

	public void setAtRefEmprestimo(Emprestimo atRefEmprestimo)
	{	this.atRefEmprestimo = atRefEmprestimo;	}
	
	//m�todo construtor
	public Usuario()
	{	nome = JOptionPane.showInputDialog("Informe o nome do usu�rio: ");
		matricula = JOptionPane.showInputDialog("Informe a matr�cula do usu�rio: ");
	}
	
	//opera��es
	public void fazerEmprestimo()
	{	Emprestimo objE = new Emprestimo();
		objE.emprestarLivro();
		atRefEmprestimo = objE;
		//atRefEmprestimo = new Emprestimo();
	}
	
	public void imprimirComprovante()
	{	JOptionPane.showMessageDialog(null,"COMPROVANTE DE EMPR�STIMO DE LIVRO\n"
			+"\nDADOS DO USU�RIO:"
			+"\nMATR�CULA............: "+matricula
			+"\nNOME.................: "+nome
			+"\n\nDADOS DO EMPR�STIMO:"
			+"\nDATA DO EMPR�STIMO...: "+atRefEmprestimo.getDataEmprestimo()
			+"\nPRAZO................: "+atRefEmprestimo.getPrazo()
			+"\nDATA DE DEVOLU��O....: "+atRefEmprestimo.getDataDevolucao()
			+"\n\nDADOS DO LIVRO:"
			+"\nT�TULO DO LIVRO......: "+atRefEmprestimo.getAtRefLivro().getNome()
			+"\nAUTOR DO LIVRO.......: "+atRefEmprestimo.getAtRefLivro().getAutor()
			+"\nEDITORA DO LIVRO.....: "+atRefEmprestimo.getAtRefLivro().getEditora()
			+"\nANO DO LIVRO.........: "+atRefEmprestimo.getAtRefLivro().getAno());		
	}
}