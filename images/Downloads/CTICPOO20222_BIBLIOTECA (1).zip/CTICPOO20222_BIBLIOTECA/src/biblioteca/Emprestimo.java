package biblioteca;

import javax.swing.JOptionPane;

public class Emprestimo
{
	//atributos comuns
	private String dataEmprestimo;
	private int prazo;
	private String dataDevolucao;
	
	//atributo de refer�ncia para tratar o relacionamento simples
	//entre as classes Emprestimo e Livro
	private Livro atRefLivro;
	
	//m�todos de acesso dos atributos comuns
	public String getDataEmprestimo()
	{	return dataEmprestimo;		}
	
	public void setDataEmprestimo(String dataEmprestimo)
	{	this.dataEmprestimo = dataEmprestimo;	}
	
	public int getPrazo()
	{	return prazo;	}
	
	public void setPrazo(int prazo)
	{	this.prazo = prazo;	}
	
	public String getDataDevolucao()
	{	return dataDevolucao;	}
	
	public void setDataDevolucao(String dataDevolucao)
	{	this.dataDevolucao = dataDevolucao;	}
	
	//m�todos de acesso do atributo de refer�ncia
	public Livro getAtRefLivro()
	{	return atRefLivro;	}

	public void setAtRefLivro(Livro atRefLivro)
	{	this.atRefLivro = atRefLivro;	}

	//m�todo construtor
	public Emprestimo()
	{	dataEmprestimo = JOptionPane.showInputDialog("Informe a data do empr�stimo: ");
		prazo = Integer.parseInt(JOptionPane.showInputDialog("Informe o prazo do empr�stimo: "));
		dataDevolucao = JOptionPane.showInputDialog("Informe a data de devolu��o do empr�stimo: ");		
	}
	
	//opera��o
	public void emprestarLivro()
	{	Livro objL = new Livro();
		atRefLivro = objL;
		//atRefLivro = new Livro();
	}
}