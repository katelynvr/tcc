package biblioteca;

public class Aluno extends Usuario
{
	//atributos comuns
	private String curso;
	private String dataNascimento;
	
	//m�todos de acesso para atributos comuns
	public String getCurso()
	{	return curso;	}
	
	public void setCurso(String curso)
	{	this.curso = curso;	}
	
	public String getDataNascimento()
	{	return dataNascimento;	}
	
	public void setDataNascimento(String dataNascimento)
	{	this.dataNascimento = dataNascimento;	}
	
	//m�todo construtor
	public Aluno()
	{	}

	//opera��o
	public void imprimirCompravante()
	{	}
}