package biblioteca;

public class Emprestimo
{
	//atributos comuns
	private String dataEmprestimo;
	private int prazo;
	private String dataDevolucao;
	
	//m�todos de acesso dos atributos comuns
	public String getDataEmprestimo()
	{	return dataEmprestimo;		}
	
	public void setDataEmprestimo(String dataEmprestimo)
	{	this.dataEmprestimo = dataEmprestimo;	}
	
	public int getPrazo()
	{	return prazo;	}
	
	public void setPrazo(int prazo)
	{	this.prazo = prazo;	}
	
	public String getDataDevolucao()
	{	return dataDevolucao;	}
	
	public void setDataDevolucao(String dataDevolucao)
	{	this.dataDevolucao = dataDevolucao;	}
	
	//m�todo construtor
	public Emprestimo()
	{	}
	
	//opera��o
	public void emprestarLivro()
	{	}
}