package biblioteca;

public class Professor extends Usuario
{
	//atributos comuns
	private String titulacao;
	private String dataAdmissao;
	
	//m�todos de acesso
	public String getTitulacao()
	{	return titulacao;	}
	
	public void setTitulacao(String titulacao)
	{	this.titulacao = titulacao;	}
	
	public String getDataAdmissao()
	{	return dataAdmissao;	}
	
	public void setDataAdmissao(String dataAdmissao)
	{	this.dataAdmissao = dataAdmissao;	}
	
	//m�todo construtor
	public Professor()
	{	}
	
	//opera��o
	public void imprimirComprovante()
	{	}

}